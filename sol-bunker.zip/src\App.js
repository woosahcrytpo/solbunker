import React, { useState } from 'react';
import Landing from './components/Landing';
import Dashboard from './components/Dashboard';
import WalletProvider from './wallet/WalletProvider';

function App() {
  const [showLanding, setShowLanding] = useState(true);

  const handleEnter = () => {
    setShowLanding(false);
  };

  return (
    <WalletProvider>
      {showLanding ? <Landing onEnter={handleEnter} /> : <Dashboard />}
    </WalletProvider>
  );
}

export default App;


